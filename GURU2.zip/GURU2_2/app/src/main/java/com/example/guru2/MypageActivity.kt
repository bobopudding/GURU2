package com.example.guru2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MypageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage)
    }
}