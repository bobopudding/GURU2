
public class WeatherData {



    }
